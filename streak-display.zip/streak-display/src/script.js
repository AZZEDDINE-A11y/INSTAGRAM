const container = document.querySelector('.container');

const starIcon = (className) => `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-star-icon lucide-star star-icon ${className}" aria-hidden="true" data-v-33ee69da=""><path d="M11.525 2.295a.53.53 0 0 1 .95 0l2.31 4.679a2.123 2.123 0 0 0 1.595 1.16l5.166.756a.53.53 0 0 1 .294.904l-3.736 3.638a2.123 2.123 0 0 0-.611 1.878l.882 5.14a.53.53 0 0 1-.771.56l-4.618-2.428a2.122 2.122 0 0 0-1.973 0L6.396 21.01a.53.53 0 0 1-.77-.56l.881-5.139a2.122 2.122 0 0 0-.611-1.879L2.16 9.795a.53.53 0 0 1 .294-.906l5.165-.755a2.122 2.122 0 0 0 1.597-1.16z"></path></svg>`
const sparkleIcon = `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-sparkle-icon lucide-sparkle star-sparkles" aria-hidden="true" data-v-33ee69da=""><path d="M9.937 15.5A2 2 0 0 0 8.5 14.063l-6.135-1.582a.5.5 0 0 1 0-.962L8.5 9.936A2 2 0 0 0 9.937 8.5l1.582-6.135a.5.5 0 0 1 .963 0L14.063 8.5A2 2 0 0 0 15.5 9.937l6.135 1.581a.5.5 0 0 1 0 .964L15.5 14.063a2 2 0 0 0-1.437 1.437l-1.582 6.135a.5.5 0 0 1-.963 0z"></path></svg>`
const starMarkup = (index) => `
  <div
    class="star"
    style="--index: ${index}; --delay-multiplier: ${0.01 * index}"
  >
    ${starIcon('star-bg')}
    ${starIcon('star-front')}
    ${sparkleIcon}
  </div>
`

container.innerHTML = panelMarkup(1);


function panelMarkup(count) {
  const variantClasses = getVariantClasses(count);
  
  let starElements = [];
  
  for(let i = 0; i < count; i++) {
    starElements.push(starMarkup(i));
  }
  
  return `
    <div class="victory-panel rainbow">
      <div class="inner">
        <div
          class="star-display ${variantClasses.join(' ')} count-${count}"
          style="--count: ${count}"
        >
          ${starElements.join(' ')}
        </div> 

        <div class="victory-text">
          <h3>${count} day streak!</h3>

          <p>
            Check back tomorrow for a new daily puzzle!
          </p>
        </div>
    </div>
  </div>`
}

function getVariantClasses(count) {
  const classes = [];
  
  if (count === 1) {
    classes.push('single');
    return classes;
  }

  if (count === 2) {
    classes.push('double');
    return classes;
  }

  if (count > 5) {
    classes.push('over-five');
  }

  if (count <= 10) {
    classes.push('circle');
    return classes;
  }

  classes.push('confetti-blaster');

  return classes;
}

document.querySelector('.theme-toggle').addEventListener('click', () => {
  if(document.documentElement.classList.contains('force-light-mode')) {
    document.documentElement.classList.remove('force-light-mode');
    document.documentElement.classList.add('force-dark-mode');
    return;
  }
  if(document.documentElement.classList.contains('force-dark-mode')) {
    document.documentElement.classList.remove('force-dark-mode');
    document.documentElement.classList.add('force-light-mode');
    return;
  }
  if(window.matchMedia('(prefers-color-scheme: dark)')) {
    document.documentElement.classList.add('force-light-mode');
    return;
  }
  document.documentElement.classList.add('force-dark-mode');
})

document.querySelector('input').addEventListener('input', (e) => {
  container.innerHTML = panelMarkup(parseInt(e.target.value));
})